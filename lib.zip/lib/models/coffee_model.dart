class Coffee {
  final int id;
  final String title;
  final double price;
  final String description;
  final String image;
  final List<String> ingredients;
  final int totalSales;

  const Coffee({
    required this.id,
    required this.title,
    required this.price,
    required this.description,
    required this.image,
    required this.ingredients,
    required this.totalSales,
  });

  factory Coffee.fromJson(Map<String, dynamic> json) {
    return Coffee(
      id: json['id'] ?? 0,
      title: json['title'] ?? '',
      price: json['price'] ?? 0,
      description: json['description'] ?? '',
      image: json['image'] ?? '',
      ingredients: json['ingredients'] != null
          ? (json['ingredients'] as List).cast<String>()
          : [],
      totalSales: json['totalSales'] ?? 0,
    );
  }
}
