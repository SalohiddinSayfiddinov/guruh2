import 'package:flutter/material.dart';
import 'package:guruh2/models/note.dart';
import 'package:guruh2/view/notes_page.dart';
import 'package:hive_flutter/hive_flutter.dart';

void main(List<String> args) async {
  await Hive.initFlutter();
  Hive.registerAdapter(NoteAdapter());
  await Hive.openBox('counterBox');
  await Hive.openBox<Note>('notes');
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Guruh 2 ning proyekti',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        // fontFamily: GoogleFonts.rosarivo().fontFamily,
      ),
      home: const NotesPage(),
    );
  }
}
