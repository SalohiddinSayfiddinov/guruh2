import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:guruh2/models/note.dart';
import 'package:hive/hive.dart';

class NotesPage extends StatefulWidget {
  const NotesPage({super.key});

  @override
  State<NotesPage> createState() => _NotesPageState();
}

class _NotesPageState extends State<NotesPage> {
  final Box<Note> noteBox = Hive.box('notes');

  void addNote() {
    showDialog(
      context: context,
      builder: (context) {
        final TextEditingController titleController = TextEditingController();
        final TextEditingController contentController = TextEditingController();
        final GlobalKey<FormState> formKey = GlobalKey<FormState>();
        return AlertDialog(
          title: const Text('Add note'),
          content: Form(
            key: formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('title'),
                const SizedBox(height: 4.0),
                TextFormField(
                  controller: titleController,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'to`ldiring';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16.0),
                const Text('content'),
                const SizedBox(height: 4.0),
                TextFormField(
                  controller: contentController,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'to`ldiring';
                    }
                    return null;
                  },
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              style: TextButton.styleFrom(foregroundColor: Colors.blue),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                if (formKey.currentState!.validate()) {
                  final newNote = Note(
                    title: titleController.text,
                    content: contentController.text,
                  );

                  noteBox.add(newNote);
                  Navigator.pop(context);
                  setState(() {});
                }
              },
              style: TextButton.styleFrom(foregroundColor: Colors.green),
              child: const Text('Add'),
            ),
          ],
        );
      },
    );
  }

  void editNote({
    required Note note,
    required int index,
  }) {
    showDialog(
      context: context,
      builder: (context) {
        final TextEditingController titleController =
            TextEditingController(text: note.title);
        final TextEditingController contentController =
            TextEditingController(text: note.content);
        final GlobalKey<FormState> formKey = GlobalKey<FormState>();
        return AlertDialog(
          title: const Text('Edit note'),
          content: Form(
            key: formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('title'),
                const SizedBox(height: 4.0),
                TextFormField(
                  controller: titleController,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'to`ldiring';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16.0),
                const Text('content'),
                const SizedBox(height: 4.0),
                TextFormField(
                  controller: contentController,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'to`ldiring';
                    }
                    return null;
                  },
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              style: TextButton.styleFrom(foregroundColor: Colors.blue),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                if (formKey.currentState!.validate()) {
                  final newNote = Note(
                    title: titleController.text,
                    content: contentController.text,
                  );

                  noteBox.putAt(index, newNote);
                  Navigator.pop(context);
                  setState(() {});
                }
              },
              style: TextButton.styleFrom(foregroundColor: Colors.green),
              child: const Text('Update'),
            ),
          ],
        );
      },
    );
  }

  void deleteNote(int index) {
    showDialog(
      context: context,
      builder: (context) {
        return CupertinoAlertDialog(
          title: const Text('O`chirishni xohlaysizmi?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              style: TextButton.styleFrom(foregroundColor: Colors.blue),
              child: const Text('Yo`q'),
            ),
            TextButton(
              onPressed: () {
                noteBox.deleteAt(index);
                setState(() {});
                Navigator.pop(context);
              },
              style: TextButton.styleFrom(foregroundColor: Colors.green),
              child: const Text('Ha'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: addNote,
      ),
      appBar: AppBar(
        title: const Text('Notes'),
      ),
      body: noteBox.isEmpty
          ? const Center(
              child: Text('Note qo`shilmagan'),
            )
          : ListView.builder(
              itemCount: noteBox.length,
              itemBuilder: (context, index) {
                final note = noteBox.getAt(index)!;
                return ListTile(
                  title: Text(note.title),
                  subtitle: Text(note.content),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    spacing: 10.0,
                    children: [
                      IconButton(
                        onPressed: () {
                          editNote(note: note, index: index);
                        },
                        icon: const Icon(
                          Icons.edit,
                          color: Colors.blue,
                        ),
                      ),
                      IconButton(
                        onPressed: () {
                          deleteNote(index);
                        },
                        icon: const Icon(
                          Icons.delete,
                          color: Colors.red,
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }
}
