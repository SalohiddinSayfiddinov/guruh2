import 'package:flutter/material.dart';
import 'package:hive/hive.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int count = 0;
  final Box counterBox = Hive.box('counterBox');

  @override
  void initState() {
    super.initState();
    count = counterBox.get('count', defaultValue: 0);
  }

  void _increment() {
    setState(() {
      count++;
      counterBox.put('count', count);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text(
          count.toString(),
          style: const TextStyle(fontSize: 50.0),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _increment,
      ),
    );
  }
}
