import 'package:flutter/material.dart';
import 'package:guruh2/repositories/coffee_repo.dart';

class CoffePage extends StatefulWidget {
  const CoffePage({super.key});

  @override
  State<CoffePage> createState() => _CoffePageState();
}

class _CoffePageState extends State<CoffePage>
    with SingleTickerProviderStateMixin {
  late final TabController tabController;
  @override
  void initState() {
    super.initState();
    tabController = TabController(length: 2, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          if (tabController.index == 0) {
            print('hot coffee chaqiraman');
          } else {
            print('iced coffee chaqiraman');
          }
        },
      ),
      appBar: AppBar(
        bottom: TabBar(
          controller: tabController,
          tabs: const [Tab(text: 'Hot'), Tab(text: 'Iced')],
        ),
      ),
      body: TabBarView(
        controller: tabController,
        children: const [
          CoffeeList(type: 'hot'),
          CoffeeList(type: 'iced'),
        ],
      ),
    );
  }
}

class CoffeeList extends StatelessWidget {
  final String type;
  const CoffeeList({super.key, required this.type});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: CoffeeRepo().getAllCoffees(type),
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          return GridView.builder(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              mainAxisExtent: 200,
            ),
            itemCount: snapshot.data!.length,
            itemBuilder: (context, index) {
              final coffee = snapshot.data![index];
              return Card(
                child: Column(
                  children: [
                    Expanded(child: Image(image: NetworkImage(coffee.image))),
                    const SizedBox(height: 10.0),
                    Text(coffee.title),
                  ],
                ),
              );
            },
          );
        } else if (snapshot.hasError) {
          return Center(
            child: Text(
              snapshot.error.toString(),
              style: const TextStyle(fontSize: 30.0),
            ),
          );
        } else {
          return const Center(
            child: CircularProgressIndicator.adaptive(),
          );
        }
      },
    );
  }
}
