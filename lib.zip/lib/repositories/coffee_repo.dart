import 'dart:convert';

import 'package:guruh2/models/coffee_model.dart';
import 'package:http/http.dart' as http;

class CoffeeRepo {
  final String baseUrl = 'https://api.sampleapis.com';

  Future<List<Coffee>> getAllCoffees(String type) async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/coffee/$type'));
      final List data = jsonDecode(response.body);
      final List<Coffee> coffees = data.map((c) => Coffee.fromJson(c)).toList();
      return coffees;
    } catch (e, s) {
      print(e);
      print(s);
      throw Exception('Xatolik yuz berdi');
    }
  }
}
